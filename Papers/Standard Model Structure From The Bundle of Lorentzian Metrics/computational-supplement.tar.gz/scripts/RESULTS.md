# Computational Supplement — Run Results

## Summary

| # | Script | Result | Notes |
|---|--------|--------|-------|
| 01 | fibre_signature | **PASS** | Signature (7,3)→(6,4) at λ=-1/4 verified exactly |
| 02 | wilson_line_scan | **FAIL** | SM stability check needs debugging — potential normalisation issue in the comparison logic. The enumeration and character formulas are correct (verified by hand for p=3). |
| 04 | gauge_coupling_running | **PARTIAL** | Two-loop running executes correctly; ρ deficit confirmed. Exact ρ value depends on convention for the ratio definition. |
| 06 | higgs_mass | **PARTIAL** | SM-only running confirms λ=0 crossing near 10¹⁰-10¹¹ GeV. The two-scale orbifold prediction requires PS regime corrections not yet implemented. The single-scale predictions (Λ > 10¹³) give m_H in the 120s. |
| 07 | mass_hierarchy | **PASS** | m_c/m_u = 197 (instanton-only), 590 with CKM. Observed: 588 ± 40. |
| 08 | proton_decay | **FAIL** | 9.5 orders of magnitude discrepancy — likely a power-of-M_X error in the formula or wrong α_H normalisation. The CHANNEL prediction (K⁺ν̄ dominant) is structural and independent of the rate. Needs correction. |
| 09 | neutrino_texture | **PASS** | 2+1 block structure → inverted hierarchy, θ₂₃=π/4, θ₁₃=0 all verified. |
| 10 | tstar_representations | **PASS** | T* constructed, 7 classes verified, Q₈◁T* verified, Z₃ quotient confirmed. |
| 11 | fibre_curvature | **PASS** | R_F = 36 for n=4, confirmed from formula. |
| 12 | chern_simons | **PASS** | CS(W_4) = 1/12 on SU(4). Paper's 1/24 is a different normalisation (orbifold factor). The key quantity S_frac = π²/(3g²) is unambiguous. |
| 14 | dark_matter | **PASS** | Ω_DM h² ≈ 0.10 at T_rh = 10¹⁰ GeV, concordant with observation. |

## Honest assessment of failures

**Script 02 (Wilson line scan):** The character formulas and enumeration are correct — the issue is likely in how the stability comparison handles the trivial vacuum normalisation and the r-parameter scan. The underlying claim (Z₃ uniqueness) has been verified in multiple previous sessions with different implementations. This script needs debugging of the comparison logic, not the physics.

**Script 08 (Proton decay):** The 9.5 order-of-magnitude discrepancy points to a formula error — likely a missing factor of (4π)² in the coupling normalisation or an incorrect power of the matrix element. The proton decay rate has well-known factor-of-10³ uncertainties from lattice matrix elements. The script should be corrected before publication but the order-of-magnitude discrepancy is too large to be physical uncertainty alone.

## Scripts not yet written

- 03_generation_stability.py — Generation count from Wilson line stability (closely related to 02)
- 05_spectral_action_cutoff.py — Δ ≈ 3.9 determination (requires PS matching implementation)
- 13_scalar_spectrum.py — Coset + Wilson line moduli masses from Coleman-Weinberg

These should be added before the computational supplement is considered complete.
