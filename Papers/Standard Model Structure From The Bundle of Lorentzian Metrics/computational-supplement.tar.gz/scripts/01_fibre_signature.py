#!/usr/bin/env python3
"""
01_fibre_signature.py — DeWitt metric signature on Sym²(T*X)

PAPER CLAIM: The one-parameter DeWitt family G_λ has signature (7,3)
for λ > -1/4 and (6,4) for λ < -1/4. Positive gravitational energy
forces λ < -1/4, selecting (6,4) and hence Pati-Salam.

INPUTS:
  - DeWitt metric formula: G_λ(h,k) = g^{μα}g^{νβ}h_{μν}k_{αβ} + λ tr(h)tr(k)
  - Lorentzian signature (1,3) for the base metric g

METHOD: Construct the 10×10 matrix of G_λ in the symmetrised basis
{f_{μν}} and compute its eigenvalues as a function of λ.
"""

import numpy as np

print("=" * 70)
print("01: DeWitt metric signature on Sym²(T*X)")
print("=" * 70)

# Base metric: Minkowski η = diag(+1, -1, -1, -1)
eta = np.diag([1.0, -1.0, -1.0, -1.0])

# Symmetrised basis for Sym²(R⁴): 10 independent components
# Order: (00), (01), (02), (03), (11), (12), (13), (22), (23), (33)
basis_indices = []
for mu in range(4):
    for nu in range(mu, 4):
        basis_indices.append((mu, nu))

assert len(basis_indices) == 10

def compute_G_lambda(lam):
    """Compute the 10×10 DeWitt metric matrix for given λ."""
    n = len(basis_indices)
    G = np.zeros((n, n))
    
    for I, (mu, nu) in enumerate(basis_indices):
        for J, (alpha, beta) in enumerate(basis_indices):
            # G_λ(f_{μν}, f_{αβ}) = g^{μα}g^{νβ} + g^{μβ}g^{να} + λ g^{μν}g^{αβ}
            # But we need the symmetrised version.
            # For basis element f_{μν} = (e_μ⊗e_ν + e_ν⊗e_μ)/√2 if μ≠ν, e_μ⊗e_μ if μ=ν
            
            # The inner product G_λ(h,k) = η^{μα}η^{νβ}h_{μν}k_{αβ} + λ η^{μν}h_{μν} η^{αβ}k_{αβ}
            # For basis vectors e_{(μν)} with components δ_{(μν),(αβ)}:
            
            # First term: η^{μ'α'}η^{ν'β'} δ_{(μ'ν'),(μν)} δ_{(α'β'),(αβ)}
            # This requires careful symmetrisation.
            
            # Direct approach: G_λ(e_{μν}, e_{αβ}) where e_{μν} has
            # components (e_{μν})_{ρσ} = (δ_{μρ}δ_{νσ} + δ_{μσ}δ_{νρ})/s_{μν}
            # with s_{μν} = 2 if μ=ν, √2 if μ≠ν (for orthonormality w.r.t. flat metric)
            
            # Actually, let's just use unnormalised basis and compute the matrix.
            # e_{μν} has (e_{μν})_{ρσ} = δ_{μρ}δ_{νσ} + δ_{μσ}δ_{νρ} for μ≠ν
            #                            = δ_{μρ}δ_{μσ} for μ=ν
            
            # G_λ(e_{μν}, e_{αβ}) = Σ_{ρσ} η^{ρρ'}η^{σσ'} (e_{μν})_{ρσ} (e_{αβ})_{ρ'σ'} 
            #                      + λ (Σ_{ρ} η^{ρσ}(e_{μν})_{ρσ})(Σ_{ρ'} η^{ρ'σ'}(e_{αβ})_{ρ'σ'})
            
            # First term (kinetic): Σ_{ρ,σ} η^{ρρ}η^{σσ} (e_{μν})_{ρσ} (e_{αβ})_{ρσ}
            # (since η is diagonal)
            
            kinetic = 0.0
            for rho in range(4):
                for sigma in range(4):
                    # (e_{μν})_{ρσ}
                    val1 = 0.0
                    if mu == nu:  # diagonal
                        if rho == mu and sigma == mu:
                            val1 = 1.0
                    else:  # off-diagonal
                        if (rho == mu and sigma == nu) or (rho == nu and sigma == mu):
                            val1 = 1.0
                    
                    # (e_{αβ})_{ρσ}
                    val2 = 0.0
                    if alpha == beta:
                        if rho == alpha and sigma == alpha:
                            val2 = 1.0
                    else:
                        if (rho == alpha and sigma == beta) or (rho == beta and sigma == alpha):
                            val2 = 1.0
                    
                    if val1 != 0 and val2 != 0:
                        kinetic += eta[rho, rho] * eta[sigma, sigma] * val1 * val2
            
            # Second term (trace): λ × tr_g(e_{μν}) × tr_g(e_{αβ})
            # tr_g(h) = η^{ρσ} h_{ρσ} = Σ_ρ η^{ρρ} h_{ρρ}
            tr1 = 0.0
            for rho in range(4):
                if mu == nu and rho == mu:
                    tr1 += eta[rho, rho]
                elif mu != nu and rho == mu and mu == nu:  # never true
                    pass
                # Actually: tr_g(e_{μν}) = η^{ρσ}(e_{μν})_{ρσ}
                # For diagonal e_{μμ}: tr = η^{μμ} = η[μ,μ]
                # For off-diagonal e_{μν}: tr = η^{μν} + η^{νμ} = 0 (diagonal metric)
            if mu == nu:
                tr1 = eta[mu, mu]
            else:
                tr1 = 0.0
            
            if alpha == beta:
                tr2 = eta[alpha, alpha]
            else:
                tr2 = 0.0
            
            G[I, J] = kinetic + lam * tr1 * tr2
    
    return G

# Compute signature for a range of λ values
print("\nλ         | Eigenvalues (sorted)                           | Sig (p,q)")
print("-" * 90)

for lam in [-1.0, -0.5, -0.3, -0.26, -0.25, -0.24, -0.2, 0.0, 0.5, 1.0]:
    G = compute_G_lambda(lam)
    eigs = np.linalg.eigvalsh(G)
    eigs_sorted = np.sort(eigs)
    n_pos = np.sum(eigs > 1e-10)
    n_neg = np.sum(eigs < -1e-10)
    n_zero = np.sum(np.abs(eigs) < 1e-10)
    sig_str = f"({n_pos},{n_neg})"
    if n_zero > 0:
        sig_str += f" + {n_zero} zero"
    
    eig_str = ", ".join(f"{e:+.3f}" for e in eigs_sorted)
    print(f"λ={lam:+6.2f}  | [{eig_str}] | {sig_str}")

# Critical value analysis
print("\n" + "=" * 70)
print("CRITICAL VALUE ANALYSIS")
print("=" * 70)

G_crit = compute_G_lambda(-0.25)
eigs_crit = np.linalg.eigvalsh(G_crit)
print(f"\nAt λ = -1/4 = -0.25:")
print(f"  Eigenvalues: {np.sort(eigs_crit)}")
print(f"  Zero eigenvalue confirms signature change at λ = -1/4")

# Identify the eigenvector for the zero mode
eigs_full, vecs = np.linalg.eigh(G_crit)
zero_idx = np.argmin(np.abs(eigs_full))
zero_vec = vecs[:, zero_idx]
print(f"  Zero eigenvector components:")
for i, (mu, nu) in enumerate(basis_indices):
    if abs(zero_vec[i]) > 0.01:
        print(f"    e_({mu},{nu}): {zero_vec[i]:.4f}")
print(f"  → This is the conformal mode (trace direction)")

# The physically relevant value
print(f"\nAt λ = -1/2 (Einstein-Hilbert / trace reversal):")
G_eh = compute_G_lambda(-0.5)
eigs_eh = np.linalg.eigvalsh(G_eh)
n_pos = np.sum(eigs_eh > 1e-10)
n_neg = np.sum(eigs_eh < -1e-10)
print(f"  Signature: ({n_pos},{n_neg})")
print(f"  Eigenvalues: {np.sort(eigs_eh)}")

# === INTEGRITY CHECK ===
print("\n" + "=" * 70)
print("INTEGRITY CHECK")
print("=" * 70)
print(f"Paper claims: signature (7,3) for λ > -1/4, (6,4) for λ < -1/4")

# Check both regimes
G_above = compute_G_lambda(0.0)
eigs_above = np.linalg.eigvalsh(G_above)
sig_above = (np.sum(eigs_above > 1e-10), np.sum(eigs_above < -1e-10))

G_below = compute_G_lambda(-0.5)
eigs_below = np.linalg.eigvalsh(G_below)
sig_below = (np.sum(eigs_below > 1e-10), np.sum(eigs_below < -1e-10))

check1 = sig_above == (7, 3)
check2 = sig_below == (6, 4)
print(f"  λ = 0.0 (above critical): signature {sig_above} — {'PASS' if check1 else 'FAIL'}")
print(f"  λ = -0.5 (below critical): signature {sig_below} — {'PASS' if check2 else 'FAIL'}")

if check1 and check2:
    print("RESULT: PASS — Fibre signature claim verified")
else:
    print("RESULT: FAIL — Signature does not match paper claim")
