# Computational Supplement: Standard Model from the Bundle of Lorentzian Metrics

## Purpose

These scripts reproduce every quantitative claim in the paper from first
principles. Each script clearly states its inputs (group theory data,
PDG parameters, geometric assumptions from the paper), performs a
transparent computation, and compares the output against the paper's
claimed result.

**No script reverse-engineers a known answer.** Every result is derived
forward from stated assumptions. Where a result disagrees with observation,
this is reported honestly.

## Requirements

- Python 3.8+
- NumPy, SciPy (standard scientific Python)

Install: `pip install numpy scipy`

## Script inventory

| # | Script | Paper claim | Key inputs |
|---|--------|-------------|------------|
| 01 | `01_fibre_signature.py` | Fibre signature (6,4) for λ<−1/4 | DeWitt metric formula |
| 02 | `02_wilson_line_scan.py` | Z₃ uniquely selects SM among non-trivial vacua | Character formulas, one-loop potential |
| 03 | `03_generation_stability.py` | 3×16 ⊕ 2×45 stabilises SM Wilson line | One-loop Hosotani potential |
| 04 | `04_gauge_coupling_running.py` | ρ = 0.546 at two-loop perturbative level | SM beta functions, PDG inputs |
| 05 | `05_spectral_action_cutoff.py` | Δ ≈ 3.9, Λ ≈ 4.3×10¹⁴ GeV, ρ = 0.717 | PS matching, b₀ asymmetry |
| 06 | `06_higgs_mass.py` | m_H ≈ 125.8 GeV from λ(Λ)=0 | Two-loop SM RG, boundary condition |
| 07 | `07_mass_hierarchy.py` | m_c/m_u ≈ 192 (instanton-only) | CS invariant, g_PS from SM running |
| 08 | `08_proton_decay.py` | τ_p ≈ 4×10³⁴ yr for p→K⁺ν̄ | M_X, CKM elements, matrix elements |
| 09 | `09_neutrino_texture.py` | Inverted hierarchy, θ₂₃=π/4, θ₁₃=0 | Z₃ charges, Type-I seesaw |
| 10 | `10_tstar_representations.py` | T* character table, McKay graph = Ê₆ | Explicit SU(2) matrices |
| 11 | `11_fibre_curvature.py` | R_F = 36, independent of λ | Symmetric space curvature formula |
| 12 | `12_chern_simons.py` | CS_SU(4)(W₄) = 1/24 | Wilson line eigenvalues |
| 13 | `13_scalar_spectrum.py` | Coset + Wilson line moduli all at M_GUT | Coleman-Weinberg potential |
| 14 | `14_dark_matter.py` | Ω_DM h² ≈ 0.12 for T_rh ~ 10¹⁰ GeV | Gravitational production formula |

## Integrity checks

Each script ends with a `# === INTEGRITY CHECK ===` section that:
1. States what the paper claims
2. States what the computation gives
3. Reports PASS/FAIL/PARTIAL with explanation
4. Flags any discrepancies honestly

## Running all scripts

```bash
for f in scripts/[0-9]*.py; do echo "=== $f ==="; python3 "$f"; echo; done
```

## Authors

Scripts written by Claude (Anthropic) as part of the paper's computational supplement.
All inputs are from the paper or PDG 2024. No parameters are fitted to observations.
