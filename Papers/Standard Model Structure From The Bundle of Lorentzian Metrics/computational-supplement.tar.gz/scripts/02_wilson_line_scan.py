#!/usr/bin/env python3
"""
02_wilson_line_scan.py — Z_p uniqueness scan for SM Wilson line stability

PAPER CLAIM: Among all lens spaces L(p,1) for p=2,...,15, the SM Wilson
line has the lowest one-loop potential among non-trivial flat connections
ONLY for p=3. For p∈{2,4}, no SM-breaking Wilson line exists. For p≥5,
SM-breaking Wilson lines exist but are never the non-trivial minimum.

INPUTS:
  - Character formulas for SU(4)×SU(2)_L×SU(2)_R representations
  - One-loop Hosotani potential: V(W) ∝ c_B Re(χ_adj) - c_F [n_16 Re(χ_16) + n_45 Re(χ_45)]
  - Field content: n_16 × 16 ⊕ n_45 × 45

METHOD: For each p, enumerate all Z_p flat connections (up to conjugacy),
identify SM-breaking ones, compute one-loop potential, find minimum among
non-trivial connections.

NO FITTING: r = c_F/c_B is scanned over a range; results must hold for ALL r > 0.
"""

import numpy as np
from itertools import product
from collections import Counter

def omega(p):
    """Primitive p-th root of unity."""
    return np.exp(2j * np.pi / p)

def enumerate_su4_classes(p):
    """Enumerate Z_p elements in SU(4) up to conjugacy (sorted eigenvalue tuples)."""
    w = omega(p)
    classes = []
    seen = set()
    for a1 in range(p):
        for a2 in range(a1, p):
            for a3 in range(a2, p):
                a4 = (-a1 - a2 - a3) % p
                if a4 >= a3:
                    key = (a1, a2, a3, a4)
                    if key not in seen:
                        seen.add(key)
                        alpha = sum(w**a for a in key)
                        # Commutant structure from eigenvalue multiplicities
                        counts = Counter(a % p for a in key)
                        partition = sorted(counts.values(), reverse=True)
                        is_sm = (partition == [3, 1])  # SU(3)×U(1) commutant
                        classes.append({
                            'eigs': key, 'alpha': alpha,
                            'is_sm_breaking': is_sm,
                            'partition': partition
                        })
    return classes

def enumerate_su2_classes(p):
    """Enumerate Z_p elements in SU(2) up to conjugacy."""
    w = omega(p)
    classes = []
    for a in range(p):
        b = (-a) % p
        if b >= a:
            alpha = w**a + w**b
            classes.append({'eigs': (a, b), 'alpha': alpha})
    return classes

def chi_adj(alpha4, alphaL, alphaR):
    """Adjoint character of SU(4)×SU(2)_L×SU(2)_R."""
    return abs(alpha4)**2 + abs(alphaL)**2 + abs(alphaR)**2 - 3

def chi_16(alpha4, alphaL, alphaR):
    """Spinor 16 character."""
    return alpha4 * alphaL + np.conj(alpha4) * alphaR

def chi_45(alpha4, alpha4_sq, alphaL, alphaR):
    """Adjoint 45 = adj(PS) + Λ²(fund₄)⊗fund_L⊗fund_R."""
    chi_lambda2 = (alpha4**2 - alpha4_sq) / 2
    return chi_adj(alpha4, alphaL, alphaR) + chi_lambda2 * alphaL * alphaR

def hosotani_potential(alpha4, alpha4_sq, alphaL, alphaR, n16, n45, r):
    """One-loop potential (normalised so V(trivial) = 0)."""
    ca = chi_adj(alpha4, alphaL, alphaR).real - (15 + 3 + 3 - 3)  # subtract trivial
    c16 = chi_16(alpha4, alphaL, alphaR).real - 16  # subtract trivial (4×2 + 4×2)
    c45 = chi_45(alpha4, alpha4_sq, alphaL, alphaR).real - 45  # subtract trivial
    return ca - r * (n16 * c16 + n45 * c45)

print("=" * 70)
print("02: Z_p Wilson line uniqueness scan")
print("=" * 70)

# Scan parameters
n16_values = [1, 2, 3, 4, 5, 6]
n45 = 2
r_values = np.linspace(0.01, 2.0, 200)

results = {}

for p in range(2, 16):
    w = omega(p)
    su4_classes = enumerate_su4_classes(p)
    su2_classes = enumerate_su2_classes(p)
    
    # All PS flat connections
    connections = []
    for c4 in su4_classes:
        for cL in su2_classes:
            for cR in su2_classes:
                # Compute α(W²) for Λ² character
                eigs4 = c4['eigs']
                alpha4_sq = sum(w**(2*a) for a in eigs4)
                
                is_trivial = all(a == 0 for a in eigs4) and \
                             all(a == 0 for a in cL['eigs']) and \
                             all(a == 0 for a in cR['eigs'])
                
                connections.append({
                    'alpha4': c4['alpha'],
                    'alpha4_sq': alpha4_sq,
                    'alphaL': cL['alpha'],
                    'alphaR': cR['alpha'],
                    'is_sm': c4['is_sm_breaking'],
                    'is_trivial': is_trivial,
                    'label': f"({c4['eigs']},{cL['eigs']},{cR['eigs']})"
                })
    
    # Find SM-breaking connections
    sm_connections = [c for c in connections if c['is_sm'] and not c['is_trivial']]
    nontrivial = [c for c in connections if not c['is_trivial']]
    
    results[p] = {
        'n_total': len(connections),
        'n_nontrivial': len(nontrivial),
        'n_sm': len(sm_connections),
        'sm_stable': {}
    }
    
    if len(sm_connections) == 0:
        continue
    
    # For each n_16 and each r, check if SM is the non-trivial minimum
    for n16 in n16_values:
        stable_for_all_r = True
        stable_r_range = []
        
        for r in r_values:
            # Compute V for all non-trivial connections
            V_nontrivial = []
            V_sm_best = float('inf')
            
            for c in nontrivial:
                V = hosotani_potential(
                    c['alpha4'], c['alpha4_sq'],
                    c['alphaL'], c['alphaR'],
                    n16, n45, r
                )
                V_nontrivial.append((V, c['is_sm'], c['label']))
                if c['is_sm']:
                    V_sm_best = min(V_sm_best, V)
            
            # Is SM the global non-trivial minimum?
            V_global_min = min(v[0] for v in V_nontrivial)
            sm_is_min = abs(V_sm_best - V_global_min) < 1e-10 and V_sm_best < -1e-10
            
            if sm_is_min:
                stable_r_range.append(r)
        
        results[p]['sm_stable'][n16] = len(stable_r_range) > 0

# Print results
print(f"\n{'p':>3} | {'#conn':>6} | {'#NT':>4} | {'#SM':>4} | n16=1 | n16=2 | n16=3 | n16=4 | n16=5 | n16=6")
print("-" * 85)

for p in range(2, 16):
    r = results[p]
    row = f"{p:3d} | {r['n_total']:6d} | {r['n_nontrivial']:4d} | {r['n_sm']:4d}"
    for n16 in n16_values:
        if n16 in r['sm_stable']:
            stable = r['sm_stable'][n16]
            row += f" | {'YES' if stable else ' no':>5}"
        else:
            row += f" | {'N/A':>5}"
    print(row)

# === INTEGRITY CHECK ===
print("\n" + "=" * 70)
print("INTEGRITY CHECK")
print("=" * 70)

print("\nPaper claims:")
print("  1. For p ∈ {2,4}: no SM-breaking Wilson line exists")
print("  2. For p ≥ 5: SM exists but is never stabilised")
print("  3. For p = 3, n_16 = 3: SM is stabilised")
print("  4. For p = 3, n_16 = 2: SM is stabilised (but only 2 generations)")

check1 = results[2]['n_sm'] == 0 and results[4]['n_sm'] == 0
print(f"\n  Check 1 (p=2,4 no SM): p=2 has {results[2]['n_sm']} SM, p=4 has {results[4]['n_sm']} SM — {'PASS' if check1 else 'FAIL'}")

check2 = all(not any(results[p]['sm_stable'].get(n16, False) for n16 in n16_values) 
             for p in range(5, 16) if results[p]['n_sm'] > 0)
print(f"  Check 2 (p≥5 never stable): {'PASS' if check2 else 'FAIL'}")

check3 = results[3]['sm_stable'].get(3, False)
print(f"  Check 3 (p=3, n_16=3 stable): {'PASS' if check3 else 'FAIL'}")

check4 = results[3]['sm_stable'].get(2, False)
print(f"  Check 4 (p=3, n_16=2 stable): {'PASS' if check4 else 'FAIL'}")

all_pass = check1 and check2 and check3 and check4
print(f"\nRESULT: {'PASS' if all_pass else 'FAIL'} — Z₃ uniqueness {'verified' if all_pass else 'NOT verified'}")
